Open the .prj file in myCBR Workbench or import the CSV manually.
This project provides three amalgams:
  - balanced_similarity       : default, balances all fields
  - structure_focused_similarity : emphasises counts and relationship types
  - actor_focused_similarity    : emphasises actor names and counts

String fields (SystemName, Description) use NGram(3) and JaroWinkler similarity
respectively — these are state-of-the-art character-level string metrics.
